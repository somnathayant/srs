import { Component,OnInit } from '@angular/core';
import { Validators,FormControl,FormGroup,FormBuilder } from '@angular/forms';
import{UserMst}from '../app/user.model'
import {UserService} from '../app/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
   userform: FormGroup;
        submitted: boolean;
        description: string;
        constructor(private fb: FormBuilder,private userService:UserService) {}
        ngOnInit() {
            this.userform = this.fb.group({
                'firstname': new FormControl(''),
                 'middleName':new FormControl(''),
                'lastname': new FormControl(''),
                'password': new FormControl(''),
                'description': new FormControl(''),
            });
    }

    checkUser(user:UserMst){
        this.userService.getUserDetails(user);
    }
}
