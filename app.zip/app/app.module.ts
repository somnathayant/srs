import { NgModule }      from '@angular/core';
import { FormsModule, ReactiveFormsModule }      from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent }  from './app.component';
import {UserService} from '../app/user.service';

@NgModule({
  imports:      [ BrowserModule, BrowserAnimationsModule, ReactiveFormsModule,
                  FormsModule ],
  declarations: [ AppComponent ],
  providers:[UserService],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
