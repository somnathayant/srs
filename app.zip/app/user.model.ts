export class UserMst {
    firstname: string;
    lastname:string;
    middleName:string;
    password:string;
    description:string;
   
}
